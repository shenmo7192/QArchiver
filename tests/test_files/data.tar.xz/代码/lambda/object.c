#include<stdlib.h>
#include"object.h"

Object *create_object(size_t mem_byte_size){
    void *data = (void *) malloc(mem_byte_size);
    Object *new_object = (Object *)malloc(sizeof(Object));
    new_object->data = data;
    new_object->mem_size = mem_byte_size;
    new_object->destroy = object_destroy;
    new_object->fill_test_byte = object_fill_test_byte;
}

static void object_destroy(Object *self){
    const size_t mem_size = self->mem_size;
    free(self->data);
    self->data = NULL;
    self->mem_size = -1;
}

static void object_fill_test_byte(Object *self){
    for(int i = 0;i<self->mem_size;i++){
        ((unsigned char *)(self->data))[i] = i%255;
    }
}