#include<stdio.h>
#include<stdlib.h>
#include"object.h"

int main(int argc, char const *argv[])
{
    Object *o1 = create_object(20);
    o1->fill_test_byte(o1);
    for(int i=0;i<100;i++){
        printf("%d", ((unsigned char*)o1->data)[i]);
    }
    o1->destroy(o1);
    for(int i=0;i<100;i++){
        printf("%d", ((unsigned char*)o1->data)[i]);
    }
    return 0;
}
